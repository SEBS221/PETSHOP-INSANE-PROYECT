import { Router } from 'express'
import Product from '../models/Product.js'

const router = Router()

router.get('/', async (req, res) => {
  const products = await Product.find()
  res.json(products)
})

router.post('/', async (req, res) => {
  const newProduct = new Product(req.body)
  await newProduct.save()
  res.status(201).json(newProduct)
})

export default router
